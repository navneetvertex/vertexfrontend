export const environment = {
  production: true,
  api_url: 'https://vertexapi.vertexsociety.com/api/'
};
