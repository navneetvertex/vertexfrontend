export const environment = {
  production: false,
  api_url: 'http://localhost:8000/api/',
  register_url: 'https://member.vertexsociety.com/account/signup',
  login_url: 'https://member.vertexsociety.com/account/login',
};