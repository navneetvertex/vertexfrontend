import { Component } from '@angular/core';

@Component({
    selector: 'app-contact-page',
    imports: [],
    standalone: true,
    templateUrl: './contact-page.component.html',
    styleUrls: ['./contact-page.component.scss']
})
export class ContactPageComponent {}