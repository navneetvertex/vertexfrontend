import { Component } from '@angular/core';

@Component({
  selector: 'app-saving-depositpage',
  imports: [],
  templateUrl: './saving-depositpage.component.html',
  styleUrl: './saving-depositpage.component.scss'
})
export class SavingDepositpageComponent {

}
