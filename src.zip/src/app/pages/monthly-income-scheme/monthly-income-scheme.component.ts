import { Component } from '@angular/core';

@Component({
  selector: 'app-monthly-income-scheme',
  imports: [],
  templateUrl: './monthly-income-scheme.component.html',
  styleUrl: './monthly-income-scheme.component.scss'
})
export class MonthlyIncomeSchemeComponent {

}
