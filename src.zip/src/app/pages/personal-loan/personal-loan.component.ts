import { Component } from '@angular/core';

@Component({
  selector: 'app-personal-loan',
  imports: [],
  templateUrl: './personal-loan.component.html',
  styleUrl: './personal-loan.component.scss'
})
export class PersonalLoanComponent {

}
