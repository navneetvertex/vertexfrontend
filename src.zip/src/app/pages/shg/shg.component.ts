import { Component } from '@angular/core';

@Component({
  selector: 'app-shg',
  imports: [],
  templateUrl: './shg.component.html',
  styleUrl: './shg.component.scss'
})
export class ShgComponent {

}
