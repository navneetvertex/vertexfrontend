import { Component } from '@angular/core';

@Component({
  selector: 'app-loan-against-fd',
  imports: [],
  templateUrl: './loan-against-fd.component.html',
  styleUrl: './loan-against-fd.component.scss'
})
export class LoanAgainstFDComponent {

}
