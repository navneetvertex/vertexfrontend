import { Component } from '@angular/core';

@Component({
  selector: 'app-gifts',
  imports: [],
  standalone: true,
  templateUrl: './gifts.component.html',
  styleUrl: './gifts.component.scss'
})
export class GiftsComponent {

}
