import { Component } from '@angular/core';

@Component({
  selector: 'app-fixed-deposit',
  imports: [],
  templateUrl: './fixed-deposit.component.html',
  styleUrl: './fixed-deposit.component.scss'
})
export class FixedDepositComponent {

}
