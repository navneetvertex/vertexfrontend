import { Component } from '@angular/core';

@Component({
  selector: 'app-sahyog-card',
  imports: [],
  templateUrl: './sahyog-card.component.html',
  styleUrl: './sahyog-card.component.scss'
})
export class SahyogCardComponent {

}
