import { Component } from '@angular/core';
import { RouterLink } from '@angular/router';

@Component({
  selector: 'app-news-events',
  imports: [],
  standalone: true,
  templateUrl: './news-events.component.html',
  styleUrl: './news-events.component.scss'
})
export class NewsEventsComponent {

}
