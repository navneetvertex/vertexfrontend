import { Component } from '@angular/core';

@Component({
  selector: 'app-self-helpgroup',
  imports: [],
  templateUrl: './self-helpgroup.component.html',
  styleUrl: './self-helpgroup.component.scss'
})
export class SelfHelpgroupComponent {

}
