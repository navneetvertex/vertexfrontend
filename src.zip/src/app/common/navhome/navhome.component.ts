import { Component } from '@angular/core';

@Component({
  selector: 'app-navhom',
  imports: [],
  templateUrl: './navhom.component.html',
  styleUrl: './navhom.component.scss'
})
export class NavhomComponent {

}
