import { Component } from '@angular/core';

@Component({
    selector: 'app-online-payment',
    imports: [],
    standalone: true,
    templateUrl: './online-payment.component.html',
    styleUrls: ['./online-payment.component.scss']
})
export class OnlinePaymentComponent {}