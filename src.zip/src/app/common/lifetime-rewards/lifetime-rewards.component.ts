import { Component } from '@angular/core';

@Component({
    selector: 'app-lifetime-rewards',
    imports: [],
    templateUrl: './lifetime-rewards.component.html',
    styleUrls: ['./lifetime-rewards.component.scss']
})
export class LifetimeRewardsComponent {}