import { Component } from '@angular/core';

@Component({
    selector: 'app-pricing-features',
    imports: [],
    templateUrl: './pricing-features.component.html',
    styleUrls: ['./pricing-features.component.scss']
})
export class PricingFeaturesComponent {}