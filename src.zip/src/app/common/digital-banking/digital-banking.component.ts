import { Component } from '@angular/core';

@Component({
    selector: 'app-digital-banking',
    imports: [],
    standalone: true,
    templateUrl: './digital-banking.component.html',
    styleUrls: ['./digital-banking.component.scss']
})
export class DigitalBankingComponent {}