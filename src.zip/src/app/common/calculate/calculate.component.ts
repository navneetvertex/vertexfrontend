import { Component } from '@angular/core';

@Component({
    selector: 'app-calculate',
    imports: [],
    standalone: true,
    templateUrl: './calculate.component.html',
    styleUrls: ['./calculate.component.scss']
})
export class CalculateComponent {}