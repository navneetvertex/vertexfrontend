import { Component } from '@angular/core';
import { RouterLink } from '@angular/router';
import { CommonModule } from '@angular/common';

@Component({
    selector: 'app-payments-transfers',
    imports: [CommonModule],
    standalone: true,
    templateUrl: './payments-transfers.component.html',
    styleUrls: ['./payments-transfers.component.scss']
})
export class PaymentsTransfersComponent {
     }
    

