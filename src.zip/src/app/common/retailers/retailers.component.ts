import { Component } from '@angular/core';

@Component({
    selector: 'app-retailers',
    imports: [],
    templateUrl: './retailers.component.html',
    styleUrls: ['./retailers.component.scss']
})
export class RetailersComponent {}