import { Component } from '@angular/core';
import { RouterLink } from '@angular/router';

@Component({
    selector: 'app-cashback-savings',
    imports: [RouterLink],
    templateUrl: './cashback-savings.component.html',
    styleUrls: ['./cashback-savings.component.scss']
})
export class CashbackSavingsComponent {}