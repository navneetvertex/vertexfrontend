import { Component } from '@angular/core';

@Component({
    selector: 'app-team',
    imports: [],
    standalone: true,
    templateUrl: './team.component.html',
    styleUrls: ['./team.component.scss']
})
export class TeamComponent {}