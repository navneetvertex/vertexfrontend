import { Component } from '@angular/core';

@Component({
    selector: 'app-subscribe',
    imports: [],
    standalone: true,
    templateUrl: './subscribe.component.html',
    styleUrls: ['./subscribe.component.scss']
})
export class SubscribeComponent {}